MoneyToFlows - Site MLM (Flask) - Package

Files included:
- app.py
- templates/ (html files)
- requirements.txt
- Dockerfile

Quick start:
1) Put these files in a GitHub repo (e.g. moneytoflows-site)
2) Set environment variables on your host:
   - ADMIN_USERNAME (e.g. @RUBENHRM777)
   - ACHAT_LINK (your Chariow product url)
   - PRODUCT_NAME, SEUIL_RECOMPENSE, REWARD_PER_REF as needed
   - SECRET_KEY (optional)
3) Deploy on Fly.io, Render or any host supporting Docker/Gunicorn.
4) Visit /init once to initialize the database.
